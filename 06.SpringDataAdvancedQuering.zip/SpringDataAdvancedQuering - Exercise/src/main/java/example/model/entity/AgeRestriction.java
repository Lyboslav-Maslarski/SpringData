package example.model.entity;

public enum AgeRestriction {
    MINOR, TEEN, ADULT
}
