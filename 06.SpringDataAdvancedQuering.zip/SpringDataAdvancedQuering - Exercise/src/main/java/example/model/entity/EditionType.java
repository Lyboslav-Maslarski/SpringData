package example.model.entity;

public enum EditionType {
    NORMAL, PROMO, GOLD
}
