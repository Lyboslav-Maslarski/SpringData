package CarDealer.services;

import CarDealer.dtos.SuppliersNoImporterDTO;

public interface SupplierService {
    SuppliersNoImporterDTO getNoImporters();
}
