package CarDealer.services;

import CarDealer.dtos.export_dtos.SaleDTO;
import CarDealer.dtos.export_dtos.SalesDTO;

import java.util.List;

public interface SaleService {
    SalesDTO getAllSales();
}
