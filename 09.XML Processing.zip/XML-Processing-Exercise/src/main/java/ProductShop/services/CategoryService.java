package ProductShop.services;

import ProductShop.exportDTOS.CategoriesExportDTO;

public interface CategoryService {
}
