package BookShopSystem.entities;

public enum EditionType {
    NORMAL, PROMO, GOLD
}
