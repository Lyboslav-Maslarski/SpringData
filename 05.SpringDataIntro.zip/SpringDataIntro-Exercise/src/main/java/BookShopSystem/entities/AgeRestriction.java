package BookShopSystem.entities;

public enum AgeRestriction {
    MINOR, TEEN, ADULT
}
