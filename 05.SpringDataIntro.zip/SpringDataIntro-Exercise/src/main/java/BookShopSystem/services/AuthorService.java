package BookShopSystem.services;

import BookShopSystem.entities.Author;

public interface AuthorService {
    Author getRandomAuthor();
}
