package BookShopSystem.services;

public interface BookService {
}
