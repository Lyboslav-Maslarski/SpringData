package UserSystem.services;

public interface UserService {
}
