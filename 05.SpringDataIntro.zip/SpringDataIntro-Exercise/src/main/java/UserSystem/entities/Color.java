package UserSystem.entities;

public enum Color {
    GREEN, BLACK, YELLOW, RED, BLUE
}
