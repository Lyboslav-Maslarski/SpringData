package _04_HospitalDatabase.core;

public interface Engine {
    void run();
}
