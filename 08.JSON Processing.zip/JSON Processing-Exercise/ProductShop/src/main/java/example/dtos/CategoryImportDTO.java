package example.dtos;

public class CategoryImportDTO {
    private String name;

    public String getName() {
        return name;
    }
}
