package example.exceptions;

public class IllegalAccessException extends RuntimeException {
    public IllegalAccessException(String message) {
        super(message);
    }
}
